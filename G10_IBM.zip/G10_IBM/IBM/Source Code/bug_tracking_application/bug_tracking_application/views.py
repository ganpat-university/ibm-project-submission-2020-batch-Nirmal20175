from django.contrib import messages
from django.shortcuts import render, redirect, HttpResponse
from bugapp.models import CustomUser
from bugapp.EmailBackEnd import EmailBackEnd
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

def BASE(request):
    return render(request, 'base.html')

def INDEX(request):
    return render(request, 'index.html')

def LOGIN(request):
    return render(request, 'login.html')

def doLogin(request):
    if request.method == "POST":
        user = EmailBackEnd.authenticate(request, username=request.POST.get("email"), password=request.POST.get("password"))
        if user != None:
            login(request, user)
            user_type = user.user_type
            if user_type == '1':
                return redirect('admin_user')
            elif user_type == '2':
                return redirect('staff_bug_details')
            elif user_type == '3':
                return redirect('userbugreports')
            else:
                messages.error(request, "Invalid Login Details")
        else:
            messages.error(request, "Invalid Login Details")
            return redirect('login')
        
@login_required(login_url='/')
def doLogout(request):
    logout(request)
    return redirect('login')

@login_required(login_url='/')
def profile(request):
    user = CustomUser.objects.get(id=request.user.id)
    context = {
        "user" : user
    }
    
    return render(request, 'profile.html', context)


@login_required(login_url='/')
def update_profile(request):
    if request.method == "POST":
        profile_pic = request.FILES.get("profile_pic")
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        username = request.POST.get("username")
        password = request.POST.get("password")
        print(profile_pic, first_name, last_name)
        
        try:
            user = CustomUser.objects.get(id=request.user.id)
            user.first_name = first_name
            user.last_name = last_name
            # user.email = email
            # user.username = username
            
            if password != None and password != "":
                user.set_password(password)
                
            if profile_pic != None and profile_pic != "":
                user.profile_pic = profile_pic

            user.save()
            messages.success(request, "Profile Updated Successfully")
            return redirect('profile')
        except:
            messages.error(request, "Failed to Update Profile")
            return redirect('update_profile')
    
    return render(request, 'update_profile.html')